完整 custom 代码数据生成脚本

请先阅读 docs/CUSTOM_CODE_DATA_SCRIPT.md。
运行 bash scripts/generate_custom_code_data.sh；可设置 PROJECT_DIR、PY、CLEAN_ROOT 和 OUT_DIR。
已有项目环境即可使用，生成器源码已包含。默认创建带北京时间的新输出目录，保留旧缓存。
代码生成逻辑为此前已运行成功的 v2，不需要旧 audit，不重新统计动作。
包中 deliveries/custom-code-generator-v2.zip 是固定版本备份及离线测试输入。
不包含用户数据、模型权重、现场配置或 Python 环境。
