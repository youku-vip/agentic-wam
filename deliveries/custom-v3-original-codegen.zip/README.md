原项目Route A的custom/v3适配。详见docs/CUSTOM_V3_CODEGEN.md。
解压包中的路径相对于项目根目录；如本地已有修改，请先备份或用Git合并，不要直接覆盖。
只有离线测试通过，真实数据和VLM生成未在当前环境执行。
