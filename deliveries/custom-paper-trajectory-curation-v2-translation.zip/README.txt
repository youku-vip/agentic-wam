Teleoperation translation curation v2

Only XYZ stability, anomaly segmentation, idle trimming and configurable smoothing/thresholds.
Default: residual plus overlapping dynamic evidence; lone dynamic peaks are review only.
Smoothing is detection only. Keep original state values.
Idle trimming is on, trims only ends, and preserves interior pauses.
Task index 2 (knob rotation in this dataset) skips position-only idle trimming.
Use --no-idle-filter to disable idle trimming.
Read docs/CUSTOM_PAPER_TRAJECTORY_CURATION.md for commands and threshold details.

Requires the existing project's src on PYTHONPATH. No GPU/model/VLM is loaded.
Export requires the verified next-state action convention. New terminal actions become holds.
Export to a new root; regenerate normalization and code/indexed caches before training.
The v1 plan/config cannot be used with v2. Historical v1 ZIP remains unchanged.

No user-uploaded trajectory values or private sample reports are included.
