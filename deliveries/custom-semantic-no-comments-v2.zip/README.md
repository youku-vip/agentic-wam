无VLM、无Python注释的代码标签版本。
详见docs/CUSTOM_SEMANTIC_TEMPLATE.md。生成脚本默认清除注释，字符串中的#保留。
候选缓存位于coding_semantic_no_comments_v2/，保留4348个episode、285262帧及此前语义去重规则。
本次只改变生成的code文本，不改变调用、参数或帧范围；真实视频语义仍待人工验收。原始缓存不受影响。
