"""Read-only structural audit. Never executes generated policy code or unpickles objects."""
import argparse
import ast
import json
from collections import defaultdict
from pathlib import Path
import torch


def check(cache, order_path, audit_path, info_path):
    info = json.loads(Path(info_path).read_text())
    data = torch.load(cache, map_location='cpu', weights_only=True)
    codes, ids = data['codes'], data['code_id_by_idx']
    assert isinstance(codes, list) and all(isinstance(c, str) for c in codes)
    assert ids.ndim == 1 and ids.dtype in (torch.int32, torch.int64)
    assert len(ids) == info['total_frames'], 'cache frame count differs from info'
    assert len(ids) and int(ids.min()) >= 0 and int(ids.max()) < len(codes)
    for c in codes:
        if c:
            tree = ast.parse(c)
            assert len(tree.body) == 1 and isinstance(tree.body[0], ast.FunctionDef)
            assert tree.body[0].name == 'policy_chunk'
            assert [a.arg for a in tree.body[0].args.args] == ['obs', 'state', 'robot', 'skills']
    order = json.loads(Path(order_path).read_text())
    records = [json.loads(l) for l in Path(audit_path).read_text().splitlines() if l.strip()]
    assert len(order) == len(records) == info['total_episodes']
    seen, offset, stats = set(), 0, defaultdict(lambda: defaultdict(int))
    for o, r in zip(order, records):
        ep = o['episode_index']
        assert ep not in seen, 'duplicate episode'
        seen.add(ep)
        assert ep == r['episode_index'] and o['task_index'] == r['task_index']
        assert o['length'] == r['n_frames'] and o['offset'] == offset
        st = stats[r['task_index']]
        st['episodes'] += 1
        st['frames'] += o['length']
        st['warning_episodes'] += bool(r.get('warning'))
        end = 0
        for s in r['spans']:
            assert s['start'] == end and end < s['end'] <= o['length'], 'gap/overlap/invalid span'
            actual = ids[offset+s['start']:offset+s['end']].unique().tolist()
            assert len(actual) == 1 and codes[actual[0]] == s['code'], 'audit/cache mismatch'
            if s['code']:
                st['labeled_frames'] += s['end']-s['start']
                for n in ast.walk(ast.parse(s['code'])):
                    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
                        st['calls_'+n.func.attr] += 1
            if r.get('task3_open_push_audit'):
                assert not any('robot.'+m+'(' in s['code'] for m in ['grasp','release','pick','place'])
            end = s['end']
        assert end == o['length'], 'incomplete episode coverage'
        offset += end
    assert offset == len(ids)
    return {'structural_checks': 'passed', 'frames': offset, 'episodes': len(order),
            'by_task': dict(stats), 'not_verified': ['real loader enumeration', 'video alignment',
            'physical contact/task success', 'tokenizer truncation', 'coordinate conventions']}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    for arg in ['cache', 'order', 'audit', 'info']:
        p.add_argument('--'+arg, required=True)
    a = p.parse_args()
    print(json.dumps(check(a.cache, a.order, a.audit, a.info), ensure_ascii=False, indent=2))
