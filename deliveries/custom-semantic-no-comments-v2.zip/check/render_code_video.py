#!/usr/bin/env python3
"""Render LeRobot v3 audit spans against real video. Never execute policy code.
Dependencies: pip install av pandas pyarrow pillow
"""
import argparse
import html
import json
import math
import random
from collections import defaultdict
from pathlib import Path

import av
import pandas as pd


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--audit', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True, help='New or empty output directory')
    ap.add_argument('--episodes', type=int, nargs='+', help='Explicit episode IDs')
    ap.add_argument('--per-task', type=int, default=2, help='Random examples per task if no --episodes')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--cameras', nargs='+', default=['head', 'left', 'right'])
    args = ap.parse_args()
    root = args.root.expanduser().resolve()
    info = json.loads((root/'meta/info.json').read_text(encoding='utf-8'))
    if not str(info.get('codebase_version', '')).startswith('v3.'):
        raise ValueError('Expected LeRobot v3 dataset')
    fps = float(info['fps'])
    if not math.isfinite(fps) or fps <= 0:
        raise ValueError('Invalid fps')
    paths = sorted((root/'meta/episodes').glob('chunk-*/file-*.parquet'))
    if not paths:
        raise FileNotFoundError('Missing meta/episodes/chunk-*/file-*.parquet')
    meta = pd.concat([pd.read_parquet(p) for p in paths], ignore_index=True)
    if meta['episode_index'].duplicated().any():
        raise ValueError('Duplicate episode metadata')
    metadata = {int(r['episode_index']): r.to_dict() for _, r in meta.iterrows()}
    records = {}
    with args.audit.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                ep = int(r['episode_index'])
                if ep in records:
                    raise ValueError(f'Duplicate audit episode {ep}')
                records[ep] = r
    if args.episodes:
        selected = list(dict.fromkeys(args.episodes))
    else:
        if args.per_task < 1:
            ap.error('--per-task must be positive')
        groups = defaultdict(list)
        for ep, r in records.items():
            groups[int(r['task_index'])].append(ep)
        rng = random.Random(args.seed)
        selected = [ep for t in sorted(groups) for ep in
                    sorted(rng.sample(sorted(groups[t]), min(args.per_task, len(groups[t]))))]
    cameras = list(dict.fromkeys(c if c.startswith('observation.images.') else
                                  'observation.images.'+c for c in args.cameras))
    jobs = defaultdict(list)
    lookup = {}
    for ep in selected:
        r, m = records[ep], metadata[ep]
        n = int(m['dataset_to_index'])-int(m['dataset_from_index'])
        if n != int(r['n_frames']):
            raise ValueError(f'Episode {ep}: metadata/audit length mismatch')
        frames = set()
        end = 0
        for s in r['spans']:
            a, b = int(s['start']), int(s['end'])
            if a != end or not 0 <= a < b <= n:
                raise ValueError(f'Episode {ep}: invalid span {a}:{b}')
            end = b
            frames.update([a, (a+b-1)//2, b-1])
        if end != n:
            raise ValueError(f'Episode {ep}: incomplete spans')
        for ci, camera in enumerate(cameras):
            if info['features'][camera]['dtype'] != 'video':
                raise ValueError(f'{camera} is not video')
            prefix = f'videos/{camera}/'
            rel = info['video_path'].format(video_key=camera,
                   chunk_index=int(m[prefix+'chunk_index']), file_index=int(m[prefix+'file_index']))
            video = (root/rel).resolve()
            if not video.is_relative_to(root):
                raise ValueError('Video path escapes dataset root')
            if not video.is_file():
                raise FileNotFoundError(video)
            start = float(m[prefix+'from_timestamp'])
            if not math.isfinite(start) or start < 0:
                raise ValueError('Invalid video offset')
            for frame in sorted(frames):
                target = start+frame/fps
                name = f'ep{ep:06d}_cam{ci}_f{frame:06d}.jpg'
                job = dict(episode=ep, camera=camera, frame=frame,
                           target_seconds=target, image='images/'+name, source=str(video))
                jobs[video].append(job)
                lookup[(ep, camera, frame)] = job
    out = args.out.expanduser().resolve()
    if out.exists() and any(out.iterdir()):
        raise ValueError('Output directory is not empty; choose a new --out')
    (out/'images').mkdir(parents=True, exist_ok=True)
    manifest = []
    # Decode each shared file once. Compare real PTS, not nominal original timestamps.
    # No silent replacement by another episode or an arbitrary nearest distant frame.
    for video, requests in jobs.items():
        pending = sorted(requests, key=lambda x: x['target_seconds'])
        index = 0
        with av.open(str(video)) as container:
            stream = container.streams.video[0]
            for frame in container.decode(stream):
                if frame.pts is None:
                    raise ValueError(f'Missing video PTS: {video}')
                actual = float(frame.pts*frame.time_base)
                while index < len(pending) and actual >= pending[index]['target_seconds']-0.51/fps:
                    job = pending[index]
                    if abs(actual-job['target_seconds']) > 0.51/fps:
                        raise ValueError(f'No frame near requested timestamp: {job}; decoded {actual}')
                    frame.to_image().save(out/job['image'], quality=90)
                    job['decoded_seconds'] = actual
                    job['time_error_seconds'] = actual-job['target_seconds']
                    manifest.append(job)
                    index += 1
                if index == len(pending):
                    break
        if index != len(pending):
            raise ValueError(f'Video ended before requested frame: {pending[index]}')
        print(f'Decoded {video.name}: {len(pending)} images', flush=True)
    esc = lambda x: html.escape(str(x), quote=True)
    page = ['<!doctype html><meta charset="utf-8"><title>代码与真实视频对照</title>',
        '<style>body{font:16px sans-serif;max-width:1500px;margin:24px auto;padding:12px;background:#f4f5f7}'
        'section{background:white;padding:18px;margin:18px 0;border-radius:8px}'
        'table{width:100%;table-layout:fixed}td{vertical-align:top;padding:6px}img{width:100%}'
        'pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#eef1f4;padding:16px}'
        'small{display:block;color:#555}h3{border-top:1px solid #ccc;padding-top:16px}</style>',
        '<h1>代码与真实视频对照</h1><p>用于人工判断，未自动认定匹配或任务成功。'
        '帧号为episode内0起始索引，区间显示包含末帧。每阶段首/中/末帧，'
        '同一图片跨阶段可能重复。时间是共享MP4编码时间：视频offset＋帧号/fps，'
        '不是原始物理采集时刻。完整运动应结合原视频判断。</p>']
    for ep in selected:
        r = records[ep]
        page += [f'<section><h2>Episode {ep} · Task {esc(r["task_index"])}</h2>',
                 f'<p>活动臂：{esc(r.get("active_arm", ""))}；{r["n_frames"]}帧</p>',
                 f'<p>审计提醒：{esc(r.get("warning", "无"))}</p>']
        for s in r['spans']:
            a, b = int(s['start']), int(s['end'])-1
            fs = [a, (a+b)//2, b]
            page += [f'<h3>{esc(s["event"])} · 帧 {a}–{b}</h3>', '<table>']
            for camera in cameras:
                page.append('<tr>')
                for f in fs:
                    j = lookup[(ep, camera, f)]
                    page.append(f'<td><img loading="lazy" src="{esc(j["image"])}">'
                                f'<small>{esc(camera)} · 帧 {f} · '
                                f'目标 {j["target_seconds"]:.4f}s / 解码 {j["decoded_seconds"]:.4f}s</small></td>')
                page.append('</tr>')
            page += ['</table>', '<pre>'+esc(s['code'] or '(无代码监督)')+'</pre>',
                     '<details><summary>阶段审计信息</summary><pre>'+esc(json.dumps(s.get('motion',{}),ensure_ascii=False,indent=2))+'</pre></details>']
        page.append('</section>')
    (out/'index.html').write_text('\n'.join(page), encoding='utf-8')
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'完成：{out / "index.html"}；episodes={selected}；images={len(manifest)}')


if __name__ == '__main__':
    main()
