原始/清洗后 custom 数据通用完整代码生成脚本 v3

请阅读 docs/CUSTOM_CODE_DATA_SCRIPT.md。
通过 DATA_ROOT 选择任一数据集，运行 bash scripts/generate_custom_code_data.sh。
原始输入自动关闭清洗边界确认；清洗后输入自动使用映射和源夹爪上下文。
兼容 CLEAN_ROOT；DATA_ROOT 优先。输出到所选根目录的带时间新目录，不覆盖旧缓存。
生成算法仍为 v2，不含代码注释，不依赖旧 audit，不修改统计值。
依赖现有项目和 Python 环境，不包含用户数据、权重或现场配置。
