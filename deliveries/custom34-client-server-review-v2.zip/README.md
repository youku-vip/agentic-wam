Custom34客户端/服务端第二轮审查与修正。先阅读deploy-custom/PAIR_REVIEW_V2.md。
分别备份并更新实际运行的服务端custom34_server.py和客户端environment.rtc_client_agenticwam模块；不要互相覆盖。
包中deploy-custom目录的测试需在具备项目src等原代码的仓库内运行，不是独立完整项目。
H=32、s_min=20、10Hz、同步无RTC、原夹爪锁和阈值不变。
15项模拟/HTTP联动测试、原RTC协议模拟测试及Custom34往返验证通过；没有连接真实机器人或加载GPU模型。
真实SDK/坐标约定/控制器回放互斥仍需核实，详见报告。
