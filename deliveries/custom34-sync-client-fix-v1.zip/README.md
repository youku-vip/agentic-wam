同步客户端控制流修正，非服务端文件。先阅读SYNC_CLIENT_REVIEW.md。
先停止客户端，备份实际environment.rtc_client_agenticwam模块文件，再对比并替换。
异步模式未改；H=32、s_min=20、10Hz和夹爪锁15步保持原值。保留原异常恢复动作，但只用当前反馈触发，并刷新每轮参考姿态。
5项模拟同步测试及原HTTP/RTC模拟测试通过，真实SDK、实机抓取未验证。
