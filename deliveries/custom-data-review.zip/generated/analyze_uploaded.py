import ast, json, sys
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
import torch
sys.path.insert(0, '/workspace/agentic-wam/src')
from agenticwam.datasets.lerobot.utils.normalizer import LinearNormalizer, load_dataset_stats_from_json

root=Path('/workspace/attachments')
def find(name):
    return next(root.glob('*/'+name))
records=[json.loads(l) for l in find('gripper_code_audit (1).jsonl').read_text().splitlines()]
data=torch.load(find('policy_code_idx_custom (1).pt'),weights_only=True,map_location='cpu')
stats=json.loads(find('dataset_stats_eef64.json').read_text())
result={'unique_codes':len(data['codes']),'by_task':{},'stats':{},'syntax_failures':[]}
def dist(v):
    return dict(zip(['min','p05','median','p95','max'],np.quantile(v,[0,.05,.5,.95,1]).tolist())) if v else None
for task in range(4):
    rr=[r for r in records if r['task_index']==task]
    warnings=Counter(w for r in rr for w in r.get('warnings',[]))
    spans=[s for r in rr for s in r['spans']]
    angles=[s['motion']['estimated_signed_angle_deg'] for s in spans if 'estimated_signed_angle_deg' in s.get('motion',{})]
    drift=[s['motion']['xyz_max_drift_m'] for s in spans if 'xyz_max_drift_m' in s.get('motion',{})]
    bad_return=[]; nonfinite=[]
    for r in rr:
        for s in r['spans']:
            tree=ast.parse(s['code'])
            for n in ast.walk(tree):
                if isinstance(n,ast.Name) and n.id.lower() in ('nan','inf'): nonfinite.append(r['episode_index'])
            if s['code'] and not isinstance(tree.body[0].body[-1],ast.Return):bad_return.append(r['episode_index'])
    labeled=sum(s['end']-s['start'] for s in spans if s['code'])
    result['by_task'][task]={'episodes':len(rr),'frames':sum(r['n_frames'] for r in rr),
      'labeled_frames':labeled,'coverage_percent':100*labeled/sum(r['n_frames'] for r in rr),
      'warnings':dict(warnings),'motion_warnings':dict(Counter(s.get('motion',{}).get('warning') for s in spans if s.get('motion',{}).get('warning'))),
      'events':dict(Counter(','.join(k for f,k in r['events']) for r in rr)),
      'span_types':dict(Counter(s['event'] for s in spans)),
      'span_lengths':{e:dist([s['end']-s['start'] for s in spans if s['event']==e]) for e in sorted(set(s['event'] for s in spans))},
      'other_arm_event_episodes':sum(bool(r['other_arm_events']) for r in rr),
      'angle_degrees':dist(angles),'xyz_drift_m':dist(drift),
      'missing_return_episodes':bad_return,'nonfinite_name_episodes':nonfinite,
      'task3_retreat_episodes':sum(bool(r.get('task3_open_push_audit',{}).get('task3_retreat_detected')) for r in rr)}
for field in ['state','action']:
    d={k:np.asarray(v) for k,v in stats[field]['default'].items()}
    issues=[]
    for k,a in d.items():
        if not np.isfinite(a).all(): issues.append('nonfinite '+k)
    for prefix in ['global_','stepwise_']:
        lo,hi=d[prefix+'min'],d[prefix+'max']
        for name,a,b in [('min<=q01',lo,d[prefix+'q01']),('q01<=q99',d[prefix+'q01'],d[prefix+'q99']),('q99<=max',d[prefix+'q99'],hi),('min<=mean',lo,d[prefix+'mean']),('mean<=max',d[prefix+'mean'],hi)]:
            if np.any(a>b+1e-7):issues.append(prefix+name)
        if np.any(d[prefix+'std']<0):issues.append('negative std')
    hand=list(range(9,31))+list(range(41,63))
    if any(np.any(a[...,hand]!=0) for a in d.values()):issues.append('hand slots not zero')
    result['stats'][field]={'issues':issues,'shapes':{k:list(v.shape) for k,v in d.items()},
       'gripper_min':d['global_min'][[31,63]].tolist(),'gripper_max':d['global_max'][[31,63]].tolist(),
       'position_min':d['global_min'][[0,1,2,32,33,34]].tolist(),'position_max':d['global_max'][[0,1,2,32,33,34]].tolist()}
loaded=load_dataset_stats_from_json(find('dataset_stats_eef64.json'))
n=LinearNormalizer({'action':[{'key':'default'}],'state':[{'key':'default'}]},True,'q01/q99',None,loaded)
for f in ['state','action']:
    assert torch.isfinite(n.normalizers[f]['default'].scale).all()
    assert torch.isfinite(n.normalizers[f]['default'].offset).all()
result['normalizer_init']='passed; finite scale/offset'
result['code_char_lengths']=dist([len(c) for c in data['codes'] if c])
result['stats_counts']={k:stats[k] for k in ['num_episodes','num_transition']}
out=Path('/workspace/custom-audit/真实缓存检查结果.json')
out.write_text(json.dumps(result,ensure_ascii=False,indent=2))
for task,v in result['by_task'].items():
    print(task,json.dumps(v,ensure_ascii=False))
print('stats',json.dumps(result['stats'],ensure_ascii=False))
print('unique_codes',result['unique_codes'],result['normalizer_init'],result['code_char_lengths'])
