#!/usr/bin/env python3
"""Read-only numerical review of an uploaded Custom34 expert/prediction chunk."""
import argparse
import ast
import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial.transform import Rotation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--metadata', type=Path, required=True)
    parser.add_argument('--metrics', type=Path, required=True)
    parser.add_argument('--chunks', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo/'src'))
    from agenticwam.utils.custom34_review import physical_errors, rotation_matrices
    import torch
    from agenticwam.datasets.lerobot.transforms.custom_unified_eef import CustomUnifiedEEFTransform

    metadata = json.loads(args.metadata.read_text())
    supplied = json.loads(args.metrics.read_text())
    with np.load(args.chunks, allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    p, g, state, valid = [arrays[k] for k in ('pred_action20', 'gt_action20', 'state34', 'valid_mask')]
    assert p.shape == g.shape == (32, 20) and state.shape == (34,) and valid.shape == (32,)
    assert all(np.isfinite(v).all() for v in arrays.values())
    hold = np.tile(state[14:34], (32, 1))
    errors = physical_errors(p, g)
    baseline_errors = physical_errors(hold, g)
    prefix_rows = []
    for n in (5, 10, 20, 32):
        mask = valid[:n]
        for side in ('left', 'right'):
            for method, fields in (('prediction', errors), ('hold_start', baseline_errors)):
                position = fields[side]['position_error_mm'][:n][mask]
                angle = fields[side]['rotation_error_deg'][:n][mask]
                prefix_rows.append(dict(steps=n, side=side, method=method, valid_steps=int(mask.sum()),
                                        position_mean_mm=float(position.mean()), position_rmse_mm=float(np.sqrt(np.mean(position**2))),
                                        position_max_mm=float(position.max()), rotation_mean_deg=float(angle.mean()),
                                        rotation_rmse_deg=float(np.sqrt(np.mean(angle**2))), rotation_max_deg=float(angle.max()),
                                        gripper_accuracy=float(fields[side]['gripper_correct'][:n][mask].mean())))

    roundtrip = {}
    transform = CustomUnifiedEEFTransform(['default'])
    base = transform._state64(torch.from_numpy(state))[None, None]
    for key in ('pred', 'gt'):
        recovered = transform.backward_action20({'state': {'default': base},
            'action': {'default': torch.from_numpy(arrays[key+'_relative64'])[None]}})['action']['default'][0].numpy()
        roundtrip[key+'_max_abs_error'] = float(np.max(np.abs(recovered-arrays[key+'_action20'])))
    angle_crosscheck = {}
    for side, offset in (('left', 0), ('right', 9)):
        rp, rg = rotation_matrices(p[:, offset+3:offset+9]), rotation_matrices(g[:, offset+3:offset+9])
        independent = np.rad2deg(Rotation.from_matrix(np.swapaxes(rg, -1, -2)@rp).magnitude())
        angle_crosscheck[side] = float(np.max(np.abs(independent-errors[side]['rotation_error_deg'])))
        for key in ('position_error_mm', 'rotation_error_deg'):
            data = errors[side][key][valid]
            assert np.isclose(data.mean(), supplied['physical'][side][key]['mean'], rtol=1e-8)
            assert np.isclose(np.sqrt(np.mean(data**2)), supplied['physical'][side][key]['rmse'], rtol=1e-8)

    tree = ast.parse(metadata['code'])  # Inspect only; never execute generated policy code.
    code_findings = []
    for call in ast.walk(tree):
        if isinstance(call, ast.Call):
            for argument in call.keywords:
                if argument.arg in ('target_rpy', 'target_pos') and isinstance(argument.value, (ast.List, ast.Tuple)):
                    if len(argument.value.elts) != 3:
                        code_findings.append(dict(argument=argument.arg, expected_length=3,
                                                  actual_length=len(argument.value.elts), value=ast.literal_eval(argument.value)))
    grippers = {}
    for side, dim in (('left', 18), ('right', 19)):
        expert_open, prediction_open = g[:, dim]>.5, p[:, dim]>.5
        close_steps = np.flatnonzero(~expert_open & valid)
        grippers[side] = dict(expert_close_steps=close_steps.tolist(),
                             prediction_close_steps=np.flatnonzero(~prediction_open & valid).tolist(),
                             prediction_closed_on_expert_close_count=int((~prediction_open[close_steps]).sum()),
                             expert_close_count=len(close_steps))
    report = dict(instruction=metadata['instruction'], checkpoint=metadata['checkpoint'], reference=metadata['reference'],
                  prefix_metrics=prefix_rows, roundtrip=roundtrip, scipy_angle_max_difference_deg=angle_crosscheck,
                  grippers=grippers, code_findings=code_findings, generated_code=metadata['code'],
                  video_decode=metadata.get('video_decode'), supplied_metrics_verified=True,
                  note='One chunk only. The hold-start baseline is a diagnostic, not a recommended task policy.')
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'analysis.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    with (args.out/'prefix_metrics.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(prefix_rows[0]))
        writer.writeheader(); writer.writerows(prefix_rows)
    with (args.out/'step_metrics.csv').open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['step', 'valid', 'left_position_error_mm', 'left_rotation_error_deg',
                         'expert_x_m', 'prediction_x_m', 'expert_y_m', 'prediction_y_m', 'expert_z_m', 'prediction_z_m',
                         'expert_left_gripper', 'prediction_left_gripper'])
        for i in range(32):
            writer.writerow([i, int(valid[i]), errors['left']['position_error_mm'][i], errors['left']['rotation_error_deg'][i],
                             g[i, 0], p[i, 0], g[i, 1], p[i, 1], g[i, 2], p[i, 2], g[i, 18], p[i, 18]])

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    t = np.arange(32)/metadata['reference']['fps']
    fig, axes = plt.subplots(2, 3, figsize=(16, 9), constrained_layout=True)
    for ax, dim, name in ((axes[0, 0], 0, 'Left X'), (axes[0, 1], 2, 'Left Z')):
        ax.plot(t, g[:, dim], label='Expert', color='tab:blue')
        ax.plot(t, p[:, dim], label='Prediction', color='tab:orange')
        ax.axhline(state[14+dim], color='gray', linestyle=':', label='Start observation')
        ax.set_title(name+' (absolute, m)'); ax.set_ylabel('m')
    ax=axes[0, 2]
    ax.step(t, g[:, 18], where='post', label='Expert', color='tab:blue')
    ax.plot(t, p[:, 18], label='Prediction', color='tab:orange')
    ax.axhline(.5, color='gray', linestyle=':');ax.set_ylim(-.1, 1.1)
    ax.set_title('Left gripper: >0.5 open, <=0.5 closed')
    for ax, metric, name in ((axes[1, 0], 'position_error_mm', 'Left position error (mm)'),
                            (axes[1, 1], 'rotation_error_deg', 'Left orientation error (degrees)')):
        ax.plot(t, errors['left'][metric], color='tab:orange', label='Prediction vs expert')
        ax.plot(t, baseline_errors['left'][metric], color='gray', linestyle=':', label='Hold-start baseline')
        ax.set_title(name)
    ax=axes[1, 2]
    ax.plot(g[:, 0], g[:, 2], color='tab:blue', label='Expert')
    ax.plot(p[:, 0], p[:, 2], color='tab:orange', label='Prediction')
    ax.scatter([state[14]], [state[16]], color='black', marker='x', label='Start observation')
    ax.scatter([g[-1, 0], p[-1, 0]], [g[-1, 2], p[-1, 2]], color=['tab:blue', 'tab:orange'])
    ax.set_title('Left X-Z path');ax.set_xlabel('X (m)');ax.set_ylabel('Z (m)');ax.set_aspect('equal', adjustable='datalim')
    for ax in axes.flat:
        ax.grid(alpha=.25);ax.legend(fontsize=8)
    for ax in (axes[0, 0], axes[0, 1], axes[0, 2], axes[1, 0], axes[1, 1]):
        ax.set_xlabel('Nominal time from observation (s)')
        ax.axvline(1.8, color='gray', linestyle='--', alpha=.6)
    fig.suptitle('Uploaded checkpoint step_008000: episode 3, frame 5, 32 valid actions\nDashed vertical line: expert closes gripper at chunk step 18 (dataset frame 23)', fontsize=12)
    fig.savefig(args.out/'left_arm_diagnosis.png', dpi=160)
    plt.close(fig)
    print(json.dumps(dict(output=str(args.out.resolve()), roundtrip=roundtrip, angle_crosscheck=angle_crosscheck,
                          left32=[row for row in prefix_rows if row['steps']==32 and row['side']=='left']), indent=2))


if __name__ == '__main__':
    main()
