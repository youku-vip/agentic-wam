Custom 数据代码生成器 v2

请阅读 docs/CUSTOM_CODE_GENERATOR_V2.md。
从清洗后数据状态直接生成，无需旧缓存、order 或 audit。
解压到独立工具目录，用现有项目环境及 PYTHONPATH=项目/src 执行 scripts/generate_custom_code_cache.py。
--confirm-curation-boundaries 仅对末尾未确认开爪，通过清洗元数据读取源夹爪上下文；不需要旧代码审计。
不包含用户数据或权重，不覆盖现场配置。
