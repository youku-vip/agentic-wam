统计与数据读取诊断工具。先阅读docs/CUSTOM_STATS_AND_GPU_DIAGNOSIS.md。
将scripts/diagnose_custom_data.py放入项目scripts目录后运行文档命令；不改原统计文件。
也可在项目根目录执行 PYTHONPATH="$PWD/src" python <解压目录>/scripts/diagnose_custom_data.py --help 。
trainer_metrics.patch只修正计时分母和梯度累积下的吞吐显示，不是GPU加速补丁。可先git apply --check，再git apply；若本地代码冲突请手动合并，不强制覆盖。
本包没有真实复算统计，也没有GPU性能测量结果。
