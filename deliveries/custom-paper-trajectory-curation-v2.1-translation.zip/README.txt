Translation trajectory curation v2.1

Scope and thresholds are unchanged from v2.
Fix: short idle windows mean unknown idle status; length selection is independent.
Default min_segment_frames=33 and idle window=32 retain the same ranges as v2.
Users choosing smaller min_segment_frames can now retain short valid pieces.
New reports separate fully dropped sources, partial sources, short pieces and idle edge trims.
Existing v2 plans can still be exported without changing their reviewed ranges.

Read docs/CUSTOM_PAPER_TRAJECTORY_CURATION.md for setup, parameters and export commands.
Run inside the existing agentic-wam project with its src on PYTHONPATH.
Regenerate code and statistics for the exported dataset's new indices.
Partial place-stage supervision does not require inventing a preceding grasp event.

No user-uploaded raw trajectories, private review results, credentials or model weights are included.
