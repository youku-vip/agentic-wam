清洗后旋钮代码标签修复工具 v1

请先阅读 docs/CURATED_KNOB_CODE_REPAIR.md。
解压到独立工具目录，使用现有项目环境和 PYTHONPATH=项目/src 运行。
只读取新旧数据，验证后写入新的缓存目录；不含用户数据、权重或现场配置。
