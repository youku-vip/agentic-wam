更新统计诊断：加入--aggregation project，同口径复现原项目逐episode等权均值和分位数包络。
把scripts/diagnose_custom_data.py更新到项目scripts/，执行docs中的project命令。
原pooled模式仍可用，但不是原项目统计文件的严格等值校验。不要自动替换现有训练/部署统计。
