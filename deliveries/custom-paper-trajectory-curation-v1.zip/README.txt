Custom paper-informed trajectory curation v1

Reference: Open-HumanScale, arXiv:2611.06817v1, section 2.2, pp. 6-7.
This is an adaptation with explicitly local thresholds, not an exact reproduction.

Read docs/CUSTOM_PAPER_TRAJECTORY_CURATION.md for Chinese instructions.
Extract into a separate TOOL_DIR inside the existing agentic-wam project.
Run with PYTHONPATH pointing to that project's src directory.

plan is read-only. export writes a new dataset root and never overwrites the source.
Default video mode links original MP4s; use --video-mode copy for independent copies.
Review gripper_transition_coverage: segmentation can remove grasp/release stages.
New terminal action rows become holds, after next-state action verification.
Regenerate normalization and all frame/episode-indexed code/caches before training.

No uploaded user trajectories, model weights, secrets or local analysis files are included.
